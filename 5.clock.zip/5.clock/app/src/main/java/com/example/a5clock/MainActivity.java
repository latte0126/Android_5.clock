package com.example.a5clock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Conversion(View view) {
        TextView date = (TextView)findViewById(R.id.textView11);
        TextView time = (TextView)findViewById(R.id.textView10);
        EditText year = (EditText)findViewById(R.id.editTextTextPersonName);
        EditText month = (EditText)findViewById(R.id.editTextTextPersonName2);
        EditText day = (EditText)findViewById(R.id.editTextTextPersonName3);
        EditText hour = (EditText)findViewById(R.id.editTextTextPersonName4);
        EditText min = (EditText)findViewById(R.id.editTextTextPersonName5);
        EditText sec = (EditText)findViewById(R.id.editTextTextPersonName7);
        TextView leapyear = (TextView)findViewById(R.id.textView13);


        int year1 = Integer.parseInt(year.getText().toString());
        int month1 = Integer.parseInt(month.getText().toString());
        int day1 = Integer.parseInt(day.getText().toString());
        int hour1 = Integer.parseInt(hour.getText().toString());
        int min1 = Integer.parseInt(min.getText().toString());
        int sec1 = Integer.parseInt(sec.getText().toString());
        if(year1%4==0 && year1%100!=0)
            leapyear.setText("是閏年");
        else
            leapyear.setText("非閏年");


        date.setText(year1+"/"+month1+"/"+day1);
        time.setText(hour1+"："+min1+"："+sec1);


    }
}